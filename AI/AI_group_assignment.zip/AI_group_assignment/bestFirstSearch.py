from queue import PriorityQueue


class Graph:
    def __init__(self):
        self.graph = {}

    def add_edge(self, u, v, w):
        if u not in self.graph:
            self.graph[u] = {}
        self.graph[u][v] = w

    def best_first_search(self, start, end):
        visited = set()
        pq = PriorityQueue()
        pq.put((0, [start]))  # Store the path along with the cost
        while not pq.empty():
            cost, path = pq.get()
            node = path[-1]  # Get the last node in the path
            if node == end:
                return cost, path  # Return both the cost and the path
            if node not in visited:
                visited.add(node)
                for neighbor, weight in self.graph[node].items():
                    new_cost = cost + weight
                    new_path = path + [neighbor]  # Extend the path
                    pq.put((new_cost, new_path))
        return None, None  # Return None if no path is found


g = Graph()
g.add_edge("A", "B", 5)
g.add_edge("A", "C", 10)
g.add_edge("B", "D", 8)
g.add_edge("C", "D", 12)
g.add_edge("D", "E", 6)

start = "A"
end = "E"
cost, path = g.best_first_search(start, end)
if cost is not None:
    print(
        f"The shortest path between {start} and {end} is: {path} with a cost of {cost}"
    )
else:
    print(f"There is no path between {start} and {end}")
